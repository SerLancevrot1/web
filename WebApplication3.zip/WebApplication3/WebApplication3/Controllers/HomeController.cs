﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Drawing.Charts;
//using exampleASPMongo.Services;
//using DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing;
//using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Newtonsoft.Json;
using WebApplication3.Models;
using Param = WebApplication3.Models.Param;
using DataPoint = WebApplication3.Models.DataPoint;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
	{
		private  IMongoCollection<Param> Parametrs { get; set; } //общая коллекция
		private List<Param> listP { get; set; } //выборка из коллекции по фильтру
		string Sinse { get; set; } 
		string For { get; set; }

		public HomeController(IConfiguration config)
		{
			//string connectionString = "mongodb://localhost";
			// подключение лежит в appsettings
			MongoClient client = new MongoClient(config.GetConnectionString("ConnectDB"));
			IMongoDatabase database = client.GetDatabase("Pepsi"); //подкоючение к ДБшке
			Parametrs = database.GetCollection<Param>("Parametrs"); //подключение к коллекции
			
		}

		public List<Param> Get()
		{
			Data();// берем значения времени , в последствии реализовать датапикер в браузере
			FilterDefinition<Param> filter = Builders<Param>.Filter.Gt("Time", Sinse) &
			   Builders<Param>.Filter.Lt("Time", For) & Builders<Param>.Filter.Eq("ID", 1);
			//фильтр по времени и ID
			listP = Parametrs.Find(filter).ToList(); //результат по фильтру
			return listP;
		}

		public void Data()
		{
			Sinse = "18.02.2020 14:20:00";
			For = "18.02.2020 14:45:00";
		}

		// GET: Home
		public ActionResult Index()
		{
			Get(); //получаем результат
			foreach (var a in listP) //значения времени должны передоваться типом double , я конвертирую
									 //каждое значение даты в BinTime , объявленное в классе. Не зкаю как иначе

			{
				a.BinTime = a.Time.ToBinary();
			}

			List<DataPoint> dataPoints = new List<DataPoint>(); // массив точек

			foreach (var i in listP)
			{
				dataPoints.Add(new DataPoint(i.BinTime , i.Value)); //время + значение , добавляем точки
			}
			ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints);
			//передаем точки в view , Index.cshtml
			return View();
		}


	}
}
